#include <iostream>
#include <string>
using namespace std;

class Person {
protected:
    string name;
    int age;

public:
    //constructor
    Person(string n, int a){
        name = n;
        age = a;
        cout << "Person constructor called" << endl;
    }

    //virtual function
    virtual void displayinfo(){
        cout << "Name: " << name << endl;
        cout << "age: " << age << endl;
    }

    //virtual destructor
    virtual ~Person(){
        cout << "Person destructor called" << endl;
    }
};

//Derrived class
class Student : public Person{
private:
    int studentID;
    double cgpa;

public:
    //Constructor
    Student(string n, int a, int id, double c) 
        :Person(n,a){
            studentID = id;
            cgpa = c;
            cout << "Student constructor called" << endl;
    }

    //overriding display info
    void displayinfo() override{
        cout << "Name: " << name << endl;
        cout << "Age: " << age << endl;
        cout << "Student_ID: " << studentID << endl;
        cout << "CGPa: " << cgpa << endl;
    }

    // destructor
    ~Student(){
        cout << "Student desttructor called" << endl;
    }
};

//main function

int main(){
    //base class pointer pointing to derrived class object

    Person * p = new Student("Taohid", 21, 20243225, 4.32);

    p -> displayinfo();



    return 0;
}
