#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Employee {
private:
    string name;
    int id;
    double salary;
    static int nextID;

public:
    void input() {
        id = nextID++;

        cout << "Enter name: ";
        cin.ignore();                 // clear buffer
        getline(cin, name);

        cout << "Enter salary: ";
        cin >> salary;
    }

    void writeToFile(ofstream &outFile) {
        outFile << id << " " << name << " " << salary << endl;
    }

    bool readFromFile(ifstream &inFile) {
        inFile >> id >> name >> salary;
        return !inFile.fail();
    }

    void display() {
        cout << "ID: " << id
             << " | Name: " << name
             << " | Salary: " << salary << endl;
    }
};

int Employee::nextID = 1;

int main() {
    int n;
    cout << "Enter number of employees: ";
    cin >> n;

    ofstream outFile("employee.txt");
    if (!outFile) {
        cout << "File could not be opened for writing!" << endl;
        return 1;
    }

    Employee emp;

    for (int i = 0; i < n; i++) {
        cout << "\nEmployee " << i + 1 << endl;
        emp.input();
        emp.writeToFile(outFile);
    }
    outFile.close();

    ifstream inFile("employee.txt");
    if (!inFile) {
        cout << "File could not be opened for reading!" << endl;
        return 1;
    }

    cout << "\n******** All Employees ********\n";

    while (emp.readFromFile(inFile)) {
        emp.display();
    }

    inFile.close();
    return 0;
}
