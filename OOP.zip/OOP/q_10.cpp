#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
using namespace std;

class Book {
public:
    string title;
    double price;

    void input() {
        cin.ignore();
        cout << "Enter book title: ";
        getline(cin, title);

        cout << "Enter book price: ";
        cin >> price;
    }

    void display() const {
        cout << "Title: " << title
             << ", Price: " << price << endl;
    }
};

// Comparator function for sorting by price
bool compareByPrice(const Book &b1, const Book &b2) {
    return b1.price < b2.price;
}

int main() {
    vector<Book> books;
    int n;

    cout << "Enter number of books: ";
    cin >> n;

    Book b;

    // Input books
    for (int i = 0; i < n; i++) {
        cout << "\nBook " << i + 1 << endl;
        b.input();
        books.push_back(b);
    }

    // Display all books
    cout << "\nAll Books:\n";
    for (const Book &bk : books) {
        bk.display();
    }

    // Display books with price > 500
    cout << "\nBooks with price greater than 500:\n";
    for (const Book &bk : books) {
        if (bk.price > 500) {
            bk.display();
        }
    }

    // Sort books by price
    sort(books.begin(), books.end(), compareByPrice);

    cout << "\nBooks sorted by price:\n";
    for (const Book &bk : books) {
        bk.display();
    }

    return 0;
}
