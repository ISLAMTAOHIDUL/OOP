#include <iostream>
#include <string>
using namespace std;

// Class template
template <class T>
class Box {
private:
    T value;

public:
    // Constructor
    Box(T v) {
        value = v;
    }

    // Member function
    T getValue() {
        return value;
    }
};

int main() {
    Box<int> intBox(100);
    Box<string> strBox("Hello Template");

    cout << "Integer value: " << intBox.getValue() << endl;
    cout << "String value: " << strBox.getValue() << endl;

    return 0;
}
