#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int main() {
    vector<int> numbers;
    int value;

    cout << "Enter 10 integers:\n";
    for (int i = 0; i < 10; i++) {
        cin >> value;
        numbers.push_back(value);
    }

    // Find maximum and minimum
    int maxVal = *max_element(numbers.begin(), numbers.end());
    int minVal = *min_element(numbers.begin(), numbers.end());

    cout << "Maximum value: " << maxVal << endl;
    cout << "Minimum value: " << minVal << endl;

    // Sort the vector
    sort(numbers.begin(), numbers.end());

    cout << "Sorted vector: ";
    for (int num : numbers) {
        cout << num << " ";
    }

    return 0;
}
