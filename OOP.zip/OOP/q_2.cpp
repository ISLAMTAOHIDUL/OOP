#include <iostream>
using namespace std;

class Account{
protected:
    double balance;

public:
    
    //constructor
    Account(double b){
        balance = b;
        cout << "Account constructor called" << endl;
    }

    //pure virtual function
    virtual double calculateInterest() =0;

    //virtual  Destructor
    virtual ~Account(){
        cout << "Destructor called" << endl;
    }
};

class SavingsAccount : public Account{
public:
    //constructor
    SavingsAccount(double b)
    : Account(b){
        cout << "contructor called" << endl;
    }

    //override function
    double calculateInterest() override{
        return balance * 0.05;
    }
};

class CurrentAccount : public Account{
public:
    //constructor
    CurrentAccount(double b)
    : Account(b){
        cout << "constructor called" << endl;
    }

    //override
    double calculateInterest() override{
        return balance * 0.02;
    }
};

int main(){
    Account * acc1 = new SavingsAccount(65000);
    Account * acc2 = new CurrentAccount(70000);

    acc1 -> calculateInterest();
    acc2 -> calculateInterest();

    cout << "Savings Account Intererst: " << acc1 -> calculateInterest() << endl;
    cout << "Current Account Intererst: " << acc2 -> calculateInterest() << endl;

    return 0;
}