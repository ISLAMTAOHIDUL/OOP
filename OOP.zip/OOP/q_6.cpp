#include <iostream>
using namespace std;

// Custom exception class
class InvalidAgeException {
public:
    const char* message() {
        return "Invalid age! Age must be 18 or above.";
    }
};

int main() {
    int age;

    cout << "Enter age: ";
    cin >> age;

    try {
        if (age < 18) {
            throw InvalidAgeException();   // throw custom exception
        }
        cout << "Age is valid." << endl;
    }
    catch (InvalidAgeException e) {
        cout << e.message() << endl;
    }

    return 0;
}