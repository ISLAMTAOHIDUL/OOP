#include <iostream>
using namespace std;

class BankAccount {
private:
    double balance;   // private data (encapsulated)

public:
    // Setter method
    void setBalance(double b) {
        if (b >= 0)
            balance = b;
    }

    // Getter method
    double getBalance() {
        return balance;
    }
};

int main() {
    BankAccount acc;
    acc.setBalance(5000);              // setting value safely
    cout << acc.getBalance();          // accessing value
    return 0;
}