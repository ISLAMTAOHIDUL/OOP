#include <iostream>
using namespace std;

// Function template
template <typename T>
T findMax(T a, T b) {
    return (a > b) ? a : b;
}

int main() {
    int i1 = 10, i2 = 20;
    float f1 = 5.5f, f2 = 3.3f;
    double d1 = 7.8, d2 = 9.2;

    cout << "Max (int): " << findMax(i1, i2) << endl;
    cout << "Max (float): " << findMax(f1, f2) << endl;
    cout << "Max (double): " << findMax(d1, d2) << endl;

    return 0;
}
