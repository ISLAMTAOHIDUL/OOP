#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(){
    string name;
    double marks;


    //write to file
    ofstream outFile("Student.txt", ios :: app);

    if (!outFile){
        cout << "File couldn't be open!" << endl;
        return 1;
    }

    cout << "Enter Student Name: ";
    cin >> name;

    cout << "Enter Student Marks: ";
    cin >> marks;
    
    outFile << name << " " << marks << endl;
    outFile.close();

    //open file for read
    ifstream inFile("Student.txt");

    if (!inFile){
        cout << "couldn't be open" << endl;
        return 1;
    }
    cout << "***********Stored Student Records***********\n";

    while (inFile >> name >> marks) {
        cout << "Name: "<< name << ", Marks: " << marks << endl;

    }
    inFile.close();

    return 0;
}