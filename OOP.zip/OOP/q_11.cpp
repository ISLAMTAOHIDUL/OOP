#include <iostream>
#include <vector>
#include <fstream>
#include <string>
using namespace std;

// --------------------
// Custom Exception
// --------------------
class InsufficientBalanceException {
public:
    const char* message() const {
        return "Error: Insufficient balance for withdrawal!";
    }
};

// --------------------
// BankAccount Class
// --------------------
class BankAccount {
private:
    int accountNumber;
    string holderName;
    double balance;

public:
    // Default constructor
    BankAccount() : accountNumber(0), holderName(""), balance(0.0) {}

    // Parameterized constructor
    BankAccount(int accNo, string name, double bal)
        : accountNumber(accNo), holderName(name), balance(bal) {}

    // Withdraw money (with exception)
    void withdraw(double amount) {
        if (amount > balance) {
            throw InsufficientBalanceException();
        }
        balance -= amount;
    }

    // Display account info
    void display() const {
        cout << "Account No: " << accountNumber
             << ", Name: " << holderName
             << ", Balance: " << balance << endl;
    }

    // Write account to file (CONST — very important)
    void writeToFile(ofstream &outFile) const {
        outFile << accountNumber << " "
                << holderName << " "
                << balance << endl;
    }

    // Read account from file (bool return — safe)
    bool readFromFile(ifstream &inFile) {
        if (inFile >> accountNumber >> holderName >> balance) {
            return true;
        }
        return false;
    }
};

// --------------------
// Main Function
// --------------------
int main() {
    vector<BankAccount> accounts;
    int n;

    cout << "Enter number of accounts: ";
    cin >> n;

    int accNo;
    string name;
    double bal;

    // Input account details
    for (int i = 0; i < n; i++) {
        cout << "\nAccount " << i + 1 << endl;

        cout << "Enter Account Number: ";
        cin >> accNo;

        cout << "Enter Holder Name: ";
        cin >> name;

        cout << "Enter Balance: ";
        cin >> bal;

        accounts.push_back(BankAccount(accNo, name, bal));
    }

    // --------------------
    // Write accounts to file
    // --------------------
    ofstream outFile("accounts.txt");
    if (!outFile) {
        cout << "Error opening file for writing!" << endl;
        return 1;
    }

    for (const BankAccount &acc : accounts) {
        acc.writeToFile(outFile);
    }
    outFile.close();

    // --------------------
    // Withdrawal with Exception Handling
    // --------------------
    double amount;
    cout << "\nEnter withdrawal amount for first account: ";
    cin >> amount;

    try {
        accounts[0].withdraw(amount);
        cout << "Withdrawal successful." << endl;
    }
    catch (InsufficientBalanceException e) {
        cout << e.message() << endl;
    }

    // --------------------
    // Read from file and display
    // --------------------
    ifstream inFile("accounts.txt");
    if (!inFile) {
        cout << "Error opening file for reading!" << endl;
        return 1;
    }

    BankAccount temp;
    cout << "\nAccounts read from file:\n";

    while (temp.readFromFile(inFile)) {
        temp.display();
    }
    inFile.close();

    return 0;
}
