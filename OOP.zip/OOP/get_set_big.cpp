#include <iostream>
#include <fstream>
#include <vector>
#include <exception>
using namespace std;

/* ===============================
   CUSTOM EXCEPTION
================================*/
class BalanceException : public exception {
public:
    const char* what() const noexcept override {
        return "Error: Invalid amount or insufficient balance!";
    }
};

/* ===============================
   BANK ACCOUNT CLASS
================================*/
class BankAccount {
private:
    int accountNo;
    string holderName;
    double balance;

public:
    static int nextAccountNo;

    // Default constructor
    BankAccount() {
        accountNo = 0;
        holderName = "";
        balance = 0.0;
    }

    // Parameterized constructor
    BankAccount(string name, double bal) {
        if (bal < 0)
            throw BalanceException();

        accountNo = nextAccountNo++;
        holderName = name;
        balance = bal;
    }

    /* ===== SETTERS ===== */
    void setHolderName(string name) {
        holderName = name;
    }

    void setBalance(double bal) {
        if (bal < 0)
            throw BalanceException();
        balance = bal;
    }

    /* ===== GETTERS ===== */
    int getAccountNo() const {
        return accountNo;
    }

    string getHolderName() const {
        return holderName;
    }

    double getBalance() const {
        return balance;
    }

    /* ===== OPERATIONS ===== */
    void credit(double amount) {
        if (amount <= 0)
            throw BalanceException();
        balance += amount;
    }

    void debit(double amount) {
        if (amount <= 0 || amount > balance)
            throw BalanceException();
        balance -= amount;
    }

    void showBalance() const {
        cout << "Account No: " << accountNo
             << " | Balance: " << balance << endl;
    }

    /* ===== FILE FUNCTIONS ===== */
    void writeToFile(ofstream& out) const {
        out << accountNo << " "
            << holderName << " "
            << balance << endl;
    }

    bool readFromFile(ifstream& in) {
        if (in >> accountNo >> holderName >> balance) {
            if (accountNo >= nextAccountNo)
                nextAccountNo = accountNo + 1;
            return true;
        }
        return false;
    }
};

int BankAccount::nextAccountNo = 1001;

/* ===============================
   FILE HANDLING USING STL
================================*/
vector<BankAccount> loadAccounts() {
    vector<BankAccount> accounts;
    ifstream in("accounts.txt");

    BankAccount acc;
    while (acc.readFromFile(in)) {
        accounts.push_back(acc);
    }
    in.close();

    return accounts;
}

void rewriteAccounts(const vector<BankAccount>& accounts) {
    ofstream out("accounts.txt");
    for (const BankAccount& acc : accounts)
        acc.writeToFile(out);
    out.close();
}

/* ===============================
   MAIN FUNCTION
================================*/
int main() {
    int choice;

    do {
        cout << "\n--- Bank Management System ---\n";
        cout << "1. Create Account\n";
        cout << "2. Credit Amount\n";
        cout << "3. Debit Amount\n";
        cout << "4. Check Balance\n";
        cout << "0. Exit\n";
        cout << "Choose: ";
        cin >> choice;

        try {
            if (choice == 1) {
                string name;
                double bal;

                cout << "Enter holder name: ";
                cin >> name;
                cout << "Enter initial balance: ";
                cin >> bal;

                BankAccount acc(name, bal);
                ofstream out("accounts.txt", ios::app);
                acc.writeToFile(out);
                out.close();

                cout << "Account created successfully!\n";
            }

            else if (choice >= 2 && choice <= 4) {
                int accNo;
                cout << "Enter account number: ";
                cin >> accNo;

                vector<BankAccount> accounts = loadAccounts();
                bool found = false;

                for (BankAccount& acc : accounts) {
                    if (acc.getAccountNo() == accNo) {
                        found = true;

                        if (choice == 2) {
                            double amt;
                            cout << "Enter credit amount: ";
                            cin >> amt;
                            acc.credit(amt);
                            cout << "Amount credited.\n";
                        }
                        else if (choice == 3) {
                            double amt;
                            cout << "Enter debit amount: ";
                            cin >> amt;
                            acc.debit(amt);
                            cout << "Amount debited.\n";
                        }
                        else {
                            acc.showBalance();
                        }
                        break;
                    }
                }

                if (!found)
                    cout << "Account not found!\n";
                else
                    rewriteAccounts(accounts);
            }
        }
        catch (exception& e) {
            cout << e.what() << endl;
        }

    } while (choice != 0);

    return 0;
}
